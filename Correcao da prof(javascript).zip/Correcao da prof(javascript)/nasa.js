/*function contagem_regressiva(){
    let numero = 10;

    while (numero > 0){
        alert ("Contagem regressiva: " + numero);
        numero--;
    }
    alert ("Lançou!!!")
}*/

function contagem_regressiva(){
    let contagem = 10;

   let sequencia = setInterval(
    function lançamento(){
        console.log(contagem);
        contagem --;
        //contagem = contagem - 1;

        if (contagem ==0){
            clearInterval(sequencia);
            console.log("lançamento!");
        
        }
    } , 1000)
}
