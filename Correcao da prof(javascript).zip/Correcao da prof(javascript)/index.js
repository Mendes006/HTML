const calc = () => {
    const mesAno = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];
    let ganhoAnual = 0;
    let gastoAnual = 0;
    for (let i = 0; i < mesAno.length; i++) {
        const ganhoBruto = window.prompt(`Qual seu ganho bruto do mês de ${mesAno[i]}`);
        const gastoBruto = window.prompt(`Qual seu gasto bruto do mês de ${mesAno[i]}`);
        ganhoAnual = ganhoAnual + parseFloat(ganhoBruto);
        gastoAnual = gastoAnual + parseFloat (gastoBruto);
    }
    const saldo = ganhoAnual - gastoAnual;
    alert(`Seu ganho bruto anual foi de ${ganhoAnual} reais e o gasto foi de ${gastoAnual} reais, e seu saldo é de ${saldo} reais.`)
    if(saldo > 0){
        alert("Você teve lucro");
    }else if(saldo < 0){
        alert("Você teve prejuizo");
    }else{
        alert("Você não teve nem lucro nem prejuizo");
    }

}