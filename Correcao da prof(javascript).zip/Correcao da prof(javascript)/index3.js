/*function consoante_vogal () {
    let letra;
    let resposta;

    

    letra = prompt("inspira uma letra e diremos se é uma vogal ou consoante! ");
    console.log(letra);

    switch (letra) {
                    
        case "A":   console.log(" Você dogitou a letra a")
        break;
        case "A":   console.log(" Você dogitou a letra A")
        break;
        case "e":   console.log(" Você dogitou a letra e")
        break;
        case "E":   console.log(" Você dogitou a letra E")
        break;
        case "i":   console.log(" Você dogitou a letra i")
        break;
        case "I":   console.log(" Você dogitou a letra I")
        break;
        case "o":   console.log(" Você dogitou a letra o")
        break;
        case "O":   console.log(" Você dogitou a letra O")
        dbreak;
        case "u":   console.log(" Você dogitou a letra u")
        break;
        case "U":   console.log(" Você dogitou a letra U")

        resposta = letra + " é uma vogal! "
        break;
        case 1: case 2:
            case '3': case '4':
            case '5': case '6': 
            case '7': case '8':
            case '9': case '0': 
                resposta = letra + " é um numero "
                break;
                default:
                    resposta = letra + " é uma consoante ";
    }
    alert(resposta);
} */

function vogalouconsoante() {
    let letra = prompt('Insira uma letra:')
    letra = letra.toLocaleLowerCase();
    let consoantes = /[bcdfghjklmnpqrstvwxyz]/
    let vogais = /[aeiou]/

    alert(consoantes.test(letra) ? "Consoante" : vogais.test(letra) ? "Vogal" : "Nenhum")
}

/*OPERADOR TERNÁRIO
Condição ? valorSeVerdadeiro : ValorSeFalso

if(consoantes.test(letra)) {
    alert(consoantes);
} else if (vogais.test(letra)) {
    alert ('vogal');
} else {
    alert('Nehum');
}*/