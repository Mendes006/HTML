/*alert("Escolha seu Sabor:\n" +
            "[1] - Chocolate - R$:1.50\n" +
            "[2] - Morango - R$2,50\n"+
            "[3] - Creme - R$2,50\n" +
            "[4] - Manga - R$3,20\n" + 
            "[5] - Melancia - R$3,40\n" +
            "[6] - Vanilla Ice - R$3,00\n" +
            "[7] - Céu Azul - R$3,60\n" +
            "[8] - Brownie - R$4,00\n" +
            "[9] - Hawaiano - R$5,00\n"
        )


    let opcao = parseInt(prompt("Digite qual opção voce escolhe: "))

    switch(opcao) {
        case 1:
            alert("O preço fica R$1,50")
            break
        case 2:
            alert("O preço fica R$2,50")
            break
        case 3:
            alert("O preço fica R$2,50")
            break
        case 4:
            alert("O preço fica R$3,20")
            break
        case 5:
            alert("O preço fica R$3,40")
            break
        case 6:
            alert("O preço fica R$3,00")
            break
        case 7:
            alert("O preço fica R$3,60") 
            break
        case 8:
            alert("O preço fica R$4,00")
            break
        case 9:
            alert("O preço fica R$5,00")
            break
        default:
            alert("OPÇÃO INVÁLIDA")




    }
    */

    function picoleteria() {
        let picoles = [['Brownie', 4.00], ['Céu Azul', 3.60], ['Chocolate', 1.50], ['Creme', 2.50], ['Hawaiano', 5.00], ['Manga', 3.20], ['Melância', 3.40], ['Morango', 2.50], ['Vanilla Ice', 3.00]];
    
        let i = 0;
        let opcao = "";
    
        for (i = 0; i < picoles.length; i++) {
            console.log(picoles[i][0]);
        }
    
        opcao = prompt("Informe o sabor de sua escolha: ");
    
        for (i = 0; i < picoles.length; i++) {
            if (opcao === picoles[i][0]) {
                console.log('O picolé de sabor ' + picoles[i][0] + ' custa R$' + picoles[i][1] + ' reais. Pagamento no crébito?');
            }
        }
    }

