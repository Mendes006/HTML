const campoNumeroPI = document.getElementById("NumeroPI");
const rotulo = document.getElementById("BotaoPI");

function TrocarRotulo() {

    if (parseInt(campoNumeroPI.value) % 2 == 0) {
        rotulo.innerHTML = "<h2> Transformar em Impar </h2>";
    } else {
        rotulo.innerHTML = "<h2>Transformar em Par</h2>";
    }
    }

    function InverterParImpar() {
        if (parseInt(campoNumeroPI.value) % 2 == 0) {
            campoNumeroPI.value = parseInt(campoNumeroPI.value) +1;
        } else {
            campoNumeroPI.value = parseInt(campoNumeroPI.value) - 1;
        }
        }
    
