function MostrarValoresDecrescentes () {
    const valores = [];

    for (let i = 0; i <4; i++){
        const numero = prompt("digite um valor inteiro");

        if (isNaN(numero)) {
            alert("Entrada inválida. Por favorm digite um valor inteiro.") 
            i--;
            continue;

        }
        valores.push(parseInt(numero));
    }
    valores.sort((a, b) => b - a);
    let mensagem = "valores em ordem decrescente: \n";
    for (const numero of valores) {
        mensagem += `${numero}\n`;

    }
    alert(mensagem);
}