const contagem = () => {
        setTimeout(() => {
            console.log("3")
        }, 1000);
        setTimeout(() => {
            console.log("2")
        }, 2000);
        setTimeout(() => {
            console.log("1")
        }, 3000);
        setTimeout(() => {
            console.log("Lançou")
        }, 4000);
}

contagem();